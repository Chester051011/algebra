### 思路流程

###### 1.VSCode下载，C++编译环境配置，测试验证成功

![Text](https://cdn.luogu.com.cn/upload/image_hosting/ol49c8ny.png)

###### 2.CMake下载，编写好CMakeLists

![Text](https://cdn.luogu.com.cn/upload/image_hosting/7kg8quow.png)

###### 3.编写代码，完成所有矩阵相关操作，编译成功

![Text](https://cdn.luogu.com.cn/upload/image_hosting/qc29o2ow.png)

![Text](https://cdn.luogu.com.cn/upload/image_hosting/l6fpjkaz.png)